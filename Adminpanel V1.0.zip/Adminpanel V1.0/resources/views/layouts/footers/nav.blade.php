<div class="row align-items-center justify-content-xl-between">
    <div class="col-xl-6">
        <div class="copyright text-center text-xl-left text-muted">
            &copy; {{ now()->year }} 
            <a class="font-weight-bold ml-1" target="_blank" href="">Our Team</a>
        </div>
    </div>

</div>