

<?php $__env->startSection('content_setting'); ?>
<?php echo $__env->make('layouts.headers.header',
array(
'class'=>'info',
'title'=>"Setting",'description'=>'',
'icon'=>'fas fa-home',
'breadcrumb'=>array([
'text'=>'Setting'
])), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid mt--7">
    <div class="col-12">
        <?php if(session('status')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('status')); ?>


            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <?php endif; ?>
    </div>
    <div class="row mb-4">
        <div class="col-md-12 mb-4">
            <div class="card text-left">
                <div class="card-header ">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h3 class="mb-0"><?php echo e(__('Setting')); ?></h3>
                        </div>

                    </div>
                </div>
                <div class="card-body pb-0">


                    <ul class="nav nav-pills nav-fill flex-column flex-sm-row mb-4" id="myTab" role="tablist">
                        <li class="nav-item <?php echo e($master['license_status'] == 0 ? 'ponter-event-none' : ''); ?>">
                            <a class="nav-link mb-sm-3 mb-md-0 <?php echo e($master['license_status'] == 1 ? 'active' : ''); ?>" id="home-basic-tab" data-toggle="tab"
                                href="#homeBasic" role="tab" aria-controls="homeBasic" aria-selected="true">Basic</a>
                        </li>
                        <li class="nav-item <?php echo e($master['license_status'] == 0 ? 'ponter-event-none' : ''); ?>">
                            <a class="nav-link mb-sm-3 mb-md-0 " id="home-basic-tab" data-toggle="tab" href="#contact"
                                role="tab" aria-controls="homeBasic" aria-selected="true">Contact us</a>
                        </li>
                        <li class="nav-item <?php echo e($master['license_status'] == 0 ? 'ponter-event-none' : ''); ?>">
                            <a class="nav-link mb-sm-3 mb-md-0 " id="home-basic-tab" data-toggle="tab" href="#appInfo"
                                role="tab" aria-controls="homeBasic" aria-selected="true">App Information</a>
                        </li>
                        <li class="nav-item <?php echo e($master['license_status'] == 0 ? 'ponter-event-none' : ''); ?>">
                            <a class="nav-link mb-sm-3 mb-md-0" id="profile-basic-tab" data-toggle="tab"
                                href="#profileBasic" role="tab" aria-controls="profileBasic" aria-selected="false">SMS
                                Gateway</a>
                        </li>
                        <li class="nav-item <?php echo e($master['license_status'] == 0 ? 'ponter-event-none' : ''); ?>">
                            <a class="nav-link mb-sm-3 mb-md-0" id="contact-basic-tab" data-toggle="tab"
                                href="#contactBasic" role="tab" aria-controls="contactBasic"
                                aria-selected="false">Payment Gateway</a>
                        </li>
                        <li class="nav-item <?php echo e($master['license_status'] == 0 ? 'ponter-event-none' : ''); ?>">
                            <a class="nav-link mb-sm-3 mb-md-0" id="contact-basic-tab" data-toggle="tab"
                                href="#pushNoti" role="tab" aria-controls="pushNoti" aria-selected="false">Push
                                Notification</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link mb-sm-3 mb-md-0 <?php echo e($master['license_status'] == 0 ? 'active' : ''); ?>" id="contact-basic-tab" data-toggle="tab"
                                href="#license" role="tab" aria-controls="pushNoti" aria-selected="false"> License </a>
                        </li>
                    </ul>
                    <div class="tab-content pb-0" id="myTabContent">
                        <div class="tab-pane fade <?php echo e($master['license_status'] == 1 ? 'show active' : ''); ?> " id="homeBasic" role="tabpanel"
                            aria-labelledby="home-basic-tab">
                            <form enctype="multipart/form-data" action="<?php echo e(route('setting.basic')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="row mb-3">
                                    <div class="form-group col-6 mb-4">
                                        <label for="inputEmail4" class="ul-form__label"> <?php echo e(__('Currency:')); ?></label>
                                        <select class="js-example-basic-multiple form-control" name="currency">
                                            <?php $__currentLoopData = $currency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <option <?php echo e($master['currency'] === $curr->code ? 'selected' : ''); ?>

                                                value="<?php echo e($curr->code); ?>">
                                                <?php echo e($curr->country .' - '.$curr->code.'('. $curr->symbol.')'); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </select>
                                        <?php $__errorArgs = ['currency'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>
                                    <div class="form-group col-6 mb-4">
                                        <label for="inputEmail4" class="ul-form__label">
                                            <?php echo e(__('Admin Commission:')); ?></label>
                                        <input type="text" name="admin_per"
                                            class="form-control  <?php $__errorArgs = ['admin_per'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-input <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            placeholder="<?php echo e(__('Please Enter Admin %')); ?>" required min="1"
                                            value="<?php echo e($master['admin_per']); ?>">
                                        <?php $__errorArgs = ['admin_per'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>
                                    

                                    <div class="col-md-12 mb-3">
                                        <div class="form-group">
                                            <label class="form-control-label"
                                                for="validationDefault01"><?php echo e(__('Main Image:')); ?></label>
                                            <input type="file" name="main_logo" class="form-control file-input "
                                                accept="image/*">

                                        </div>
                                    </div>
                                    <div class="col-2">
                                        <h5> <?php echo e(__('Enable notification')); ?></h5>

                                    </div>
                                    <div class="col-4 pr-0">
                                        <label class="switch switch-primary mr-3">
                                            <span> <?php echo e(__('')); ?></span>
                                            <input type="checkbox" value="1" name="notification"
                                                <?php echo e($master['notification'] ? 'checked' : ''); ?>>
                                            <span class="slider"></span>
                                        </label>


                                    </div>
                                    <div class="col-2 mt-4">
                                        <h5> <?php echo e(__('Offline Payment')); ?></h5>

                                    </div>
                                    <div class="col-4 mt-4 pr-0">
                                        <label class="switch switch-primary mr-3">
                                            <span> <?php echo e(__('')); ?></span>
                                            <input type="checkbox" value="1" name="offline_payment"
                                                <?php echo e($master['offline_payment'] ? 'checked' : ''); ?>>
                                            <span class="slider"></span>
                                        </label>


                                    </div>
                                </div>
                                <div class="card-footer bg-transparent">
                                    <div class="mc-footer">
                                        <div class="row">
                                            <div class="col-lg-12 text-right">
                                                <button type="submit"
                                                    class="btn  btn-primary m-1"><?php echo e(__('Submit')); ?></button>
                                                <button type="reset"
                                                    class=" btn  btn-secondary m-1"><?php echo e(__('Reset')); ?></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane fade " id="contact" role="tabpanel" aria-labelledby="home-basic-tab">
                            <form enctype="multipart/form-data" action="<?php echo e(route('base.update')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="row mb-3">

                                    <div class="form-group col-6 mb-4">
                                        <label for="inputEmail4" class="ul-form__label"> <?php echo e(__('Phone No:')); ?></label>
                                        <input type="text" name="phone_no"
                                            class="form-control  <?php $__errorArgs = ['phone_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-input <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required
                                            min="1" value="<?php echo e($master['phone_no']); ?>">
                                        <?php $__errorArgs = ['phone_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>
                                    <div class="form-group col-6 mb-4">
                                        <label for="inputEmail4" class="ul-form__label"> <?php echo e(__('Email:')); ?></label>
                                        <input type="text" name="email"
                                            class="form-control  <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-input <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required
                                            min="1" value="<?php echo e($master['email']); ?>">
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>
                                    <div class="form-group col-12 mb-4">
                                        <label for="inputEmail4" class="ul-form__label"> <?php echo e(__('Address:')); ?></label>
                                        <textarea name="address"
                                            class="form-control  <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-input <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" cols="30"
                                            rows="10"><?php echo e($master['address']); ?></textarea>

                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>
                                </div>
                                <div class="card-footer bg-transparent">
                                    <div class="mc-footer">
                                        <div class="row">
                                            <div class="col-lg-12 text-right">
                                                <button type="submit"
                                                    class="btn  btn-primary m-1"><?php echo e(__('Submit')); ?></button>
                                                <button type="reset"
                                                    class=" btn  btn-secondary m-1"><?php echo e(__('Reset')); ?></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane fade " id="appInfo" role="tabpanel" aria-labelledby="home-basic-tab">
                            <form enctype="multipart/form-data" action="<?php echo e(route('base.update')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="row mb-3">

                                    <div class="form-group col-6 mb-4">
                                        <label for="inputEmail4" class="ul-form__label"> <?php echo e(__('IOS version:')); ?></label>
                                        <input type="text" name="ios_version"
                                            class="form-control  <?php $__errorArgs = ['ios_version'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-input <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required
                                            min="1" value="<?php echo e($master['ios_version']); ?>">
                                        <?php $__errorArgs = ['ios_version'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>
                                    <div class="form-group col-6 mb-4">
                                        <label for="inputEmail4" class="ul-form__label">
                                            <?php echo e(__('Android version:')); ?></label>
                                        <input type="text" name="android_version"
                                            class="form-control  <?php $__errorArgs = ['android_version'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-input <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            required min="1" value="<?php echo e($master['android_version']); ?>">
                                        <?php $__errorArgs = ['android_version'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>

                                </div>
                                <div class="card-footer bg-transparent">
                                    <div class="mc-footer">
                                        <div class="row">
                                            <div class="col-lg-12 text-right">
                                                <button type="submit"
                                                    class="btn  btn-primary m-1"><?php echo e(__('Submit')); ?></button>
                                                <button type="reset"
                                                    class=" btn  btn-secondary m-1"><?php echo e(__('Reset')); ?></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="profileBasic" role="tabpanel"
                            aria-labelledby="profile-basic-tab">
                            <?php if(View::exists('admin.twilio.index') && Route::has('twilio.update')): ?>
                            <?php echo $__env->make('admin.twilio.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php else: ?>
                            <h3 class="m-3 text-danger">Please Add SMS Module To access this TAB</h3>
                            <?php endif; ?>
                        </div>
                        <div class="tab-pane fade" id="pushNoti" role="tabpanel" aria-labelledby="der">
                            <?php if(View::exists('admin.onesignal.index') && Route::has('onesignal.update')): ?>
                            <?php echo $__env->make('admin.onesignal.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php else: ?>
                            <h3 class="m-3 text-danger">Please Add one signal Module To access this TAB</h3>
                            <?php endif; ?>
                        </div>
                        <div class="tab-pane fade" id="contactBasic" role="tabpanel"
                            aria-labelledby="contact-basic-tab">

                            <?php if(View::exists('admin.paymentGateway.stripeIndex') && Route::has('stripe.update')): ?>
                            <?php echo $__env->make('admin.paymentGateway.stripeIndex', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php else: ?>
                            <h3 class="m-3 text-danger">Please Add Stripe Module To access this TAB</h3>
                            <?php endif; ?>

                            <?php if(View::exists('admin.paymentGateway.paypalIndex') && Route::has('paypal.update')): ?>
                            <?php echo $__env->make('admin.paymentGateway.paypalIndex', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php else: ?>
                            <h3 class="m-3 text-danger">Please Add PayPal Module To access this TAB</h3>
                            <?php endif; ?>

                            <?php if(View::exists('admin.paymentGateway.razorIndex') && Route::has('razor.update')): ?>
                            <?php echo $__env->make('admin.paymentGateway.razorIndex', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php else: ?>
                            <h3 class="m-3 text-danger">Please Add PayPal Module To access this TAB</h3>
                            <?php endif; ?>

                        </div>
                        
                        <div class="tab-pane fade <?php echo e($master['license_status'] == 0 ? 'show active' : ''); ?>" id="license" role="tabpanel" aria-labelledby="home-basic-tab">
                            <form enctype="multipart/form-data" action="<?php echo e(route('license.update')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="row mb-3">

                                    <div class="form-group col-6 mb-4">
                                        <label for="inputEmail4" class="ul-form__label"> <?php echo e(__('License Code')); ?> </label>
                                        <input type="text" name="license_code"
                                            class="form-control  <?php $__errorArgs = ['license_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-input <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required
                                            value="<?php echo e($master['license_code']); ?>"
                                            <?php echo e($master['license_status'] == 1  ? 'disabled': ''); ?>>
                                        <?php $__errorArgs = ['license_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>
                                    <div class="form-group col-6 mb-4">
                                        <label for="inputEmail4" class="ul-form__label">
                                            <?php echo e(__('License Client Name')); ?></label>
                                        <input type="text" name="license_client_name"
                                            class="form-control  <?php $__errorArgs = ['license_client_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-input <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            required value="<?php echo e($master['license_client_name']); ?>"
                                            <?php echo e($master['license_status'] == 1  ? 'disabled': ''); ?>>
                                        <?php $__errorArgs = ['license_client_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-div"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                    </div>

                                </div>
                                <?php if($master['license_status'] == 0): ?>
                                    <div class="card-footer bg-transparent">
                                        <div class="mc-footer">
                                            <div class="row">
                                                <div class="col-lg-12 text-right">
                                                    <button type="submit"
                                                        class="btn  btn-primary m-1"><?php echo e(__('Submit')); ?></button>
                                                    <button type="reset"
                                                        class=" btn  btn-secondary m-1"><?php echo e(__('Reset')); ?></button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> 
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\newxampp\htdocs\extra\lofule\lofule\resources\views/admin/setting/index.blade.php ENDPATH**/ ?>