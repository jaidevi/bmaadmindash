<form enctype="multipart/form-data" action="<?php echo e(route('stripe.update')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="row mb-3 mt-3">
        <div class="col-2">
            <h5> <?php echo e(__('Stripe Payment Gateway')); ?></h5>
        </div>
        <div class="col-10 pr-0">
            <label class="switch switch-success mr-3">
                <span> <?php echo e(__('')); ?></span>
                <input type="checkbox" value="1" name="stipe_status" <?php echo e($master['stipe_status'] ? 'checked' : ''); ?>>
                <span class="slider"></span>
            </label>


        </div>
        <div class="form-group col-6 mb-4">
            <label for="inputEmail4" class="ul-form__label"> <?php echo e(__('STRIPE_SECRET:')); ?>

                <a href="https://stripe.com/docs/keys" target="_blank" rel="noopener noreferrer">How To Integrate</a>
            </label>
            <div class="input-group">
                <input type="password" name="STRIPE_SECRET"
                    class="form-control  <?php $__errorArgs = ['STRIPE_SECRET'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-input <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    placeholder="<?php echo e(__('Please Enter Valid Key')); ?>" required min="1"
                    value="<?php echo e($master['STRIPE_SECRET'] ?? ''); ?>">
                <div class="input-group-append">
                    <span class="input-group-text bg-transparent pointer" onclick="toggleInput('STRIPE_SECRET')">
                        <i class="far fa-eye"></i>
                    </span>
                </div>
            </div>
            <?php $__errorArgs = ['STRIPE_SECRET'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-div"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>
        <div class="form-group col-6 mb-4">

            <label for="inputEmail4" class="ul-form__label"> <?php echo e(__('STRIPE_KEY:')); ?></label>
            <div class="input-group">
                <input type="password" name="STRIPE_KEY"
                    class="form-control  <?php $__errorArgs = ['STRIPE_KEY'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> invalid-input <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    placeholder="<?php echo e(__('Please Enter Valid Key')); ?>" required min="1"
                    value="<?php echo e($master['STRIPE_KEY'] ?? ''); ?>" id="STRIPE_KEY">
                <div class="input-group-append">
                    <span class="input-group-text bg-transparent pointer" onclick="toggleInput('STRIPE_KEY')">
                        <i class="far fa-eye"></i>
                    </span>
                </div>
            </div>
            <?php $__errorArgs = ['STRIPE_KEY'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-div"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>
    </div>
    <div class="card-footer bg-transparent">
        <div class="mc-footer">
            <div class="row">
                <div class="col-lg-12 text-right">
                    <button type="submit" class="btn btn-raised ripple btn-raised-primary m-1"><?php echo e(__('Submit')); ?></button>
                    <button type="reset"
                        class=" btn btn-raised ripple btn-raised-secondary m-1"><?php echo e(__('Reset')); ?></button>
                </div>
            </div>
        </div>
    </div>
</form>
<?php /**PATH C:\newxampp\htdocs\extra\lofule\lofule\resources\views/admin/paymentGateway/stripeIndex.blade.php ENDPATH**/ ?>