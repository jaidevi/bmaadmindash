



<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.headers.header',
array(
'class'=>'info',
'title'=>"Provider",'description'=>'',
'icon'=>'fas fa-home',
'breadcrumb'=>array([
'text'=>'Provider List'
])), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid mt--7">
    <div class="row">
        <div class="col">
            <div class="card shadow">
                <div class="card-header mb-3">
                    <div class="row align-items-center">
                        <div class="col-8">
                            <h3 class="mb-0"><?php echo e(__('Provider')); ?></h3>
                            <form action="<?php echo e(route('earning.filter')); ?>" method="post">
                           <?php echo csrf_field(); ?>
                                <div class="col-12 m-2 ml-0 mt-0" style="display: flex;">
                                    <select class="form-control" name="index" style="width: 200px">
                                        <?php $__currentLoopData = $master; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>"><?php echo e($item['start_date'] .' to '. $item['end_date']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <button class="btn btn-primary ml-3" type="submit">Submit</button>
                                </div>
                            </form>
                        </div>

                    </div>
                </div>
               

                <div class="col-12">
                    <?php if(session('status')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo e(session('status')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="table-responsive py-4">
                    <table id="dataTable" class="table table-flush">
                        <thead class="thead-light">
                         <tr>
                                <th>#</th>
                                <th><?php echo e(__('Provider Name')); ?></th>
                                <th><?php echo e(__('Total Task')); ?></th>
                                <th><?php echo e(__('Total')); ?></th>
                                <th><?php echo e(__('Provider Share')); ?></th>
                                <th><?php echo e(__('Admin Share')); ?></th>
                                <th><?php echo e(__('Balance')); ?></th>
                                <th><?php echo e(__('Action')); ?></th>
                            
                            </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $earingD; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td>
                            
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('serviceProvider_show')): ?>
                                    <a href="<?php echo e(route('serviceProvider.show', ['id'=>$item->provider->id])); ?>">
                                        <?php echo e($item->provider->name ?? ""); ?>

                                    </a>
                                    <?php elseif (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('earing_access')): ?>
                                    <?php echo e($item->provider->name ?? ''); ?>

                                    <?php endif; ?>
                                    <?php echo e($item->provider->name ?? ""); ?>

                                </td>
                                <td>
                                    <?php echo e($item->d_total_task); ?>

                                </td>
                                <td>
                                    <?php echo e($item->d_total_amount); ?>

                                </td>
                                <td>
                                    <?php echo e($item->d_provider_share); ?>

                                </td>
                                <td>
                                    <?php echo e($item->d_admin_share); ?>

                                </td>
                                <td>
                                    <?php if($item->d_balance >= 0): ?>
                                    <p class="text-success"><?php echo e($item->d_balance); ?> </p>
                                    <?php else: ?>
                                    <p class="text-danger"><?php echo e($item->d_balance); ?> </p>
                                    <?php endif; ?>
                            
                                </td>
                                <td class="d-flex">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('earning_show')): ?>
                            
                                    <form action="<?php echo e(route('earning.show')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="provider_id" value="<?php echo e($item->provider->id); ?>">
                                        <button class="btn btn-outline-info  m-1" type="submit">
                                            View
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                </td>
                            
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>

                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\newxampp\htdocs\extra\lofule\lofule\resources\views/admin/earning/index.blade.php ENDPATH**/ ?>